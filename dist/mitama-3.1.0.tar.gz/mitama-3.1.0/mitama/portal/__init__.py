from mitama.app import Builder

from .main import App


class AppBuilder(Builder):
    app = App
