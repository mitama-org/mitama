from mitama.db import BaseDatabase
# from mitama.db.types import *


class Database(BaseDatabase):
    pass


db = Database()

# db.create_all()
