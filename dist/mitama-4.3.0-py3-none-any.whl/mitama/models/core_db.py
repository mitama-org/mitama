from mitama.db import BaseDatabase

class Database(BaseDatabase):
    pass

db = Database(prefix='mitama')
